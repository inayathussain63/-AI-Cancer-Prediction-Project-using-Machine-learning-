# Prediction Report - Team Makalu

## Multi-Model Evaluation

We expanded our analysis to compare five different Machine Learning models:
- RandomForest
- GradientBoosting
- LogisticRegression
- SVM
- KNN

### Comparative Results
The attached `model_comparison_plot.png` illustrates the performance differences across Accuracy, F1-Score, and AUC.

The model with the highest accuracy was selected as the **Best Model**, and its Confusion Matrix is visualized in `prediction_plot_cm.png`.

### Key Insights
- **Model Selection**: Comparing multiple algorithms allows us to choose the one that best captures the patterns in the health data.
- **Performance**: The detailed metrics table in `AI_Makalu_ModelMetrics.xlsx` provides a granular view of trade-offs between Precision and Recall for each model.
